#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
#include "BST.cpp"
using namespace std;
int main()
{
    TreeNode *root = new TreeNode(5);
    BST b1 = BST(root);
    if (b1.isEmpty())
    {
        cout << "True" << endl;
    }
    else
        cout << "False" << endl;
    b1.insert(new TreeNode(6));
    b1.insert(new TreeNode(4));
    b1.insert(new TreeNode(2));
    cout << "PreOrder: ";
    b1.PreOrder(root);
    cout << endl;
    cout << "InOrder: ";
    b1.InOrder(root);
    cout << endl;
    cout << "PostOrder: ";
    b1.PostOrder(root);
    cout << endl;
    TreeNode *result = b1.Recursive_Search(root, 4);
    if (result)
    {
        cout << "Found: " << result->val << endl;
    }
    else
    {
        cout << "Not Found!" << endl;
    }
    b1.insert(new TreeNode(7));
    cout << "PreOrder: ";
    b1.PreOrder(root);
    cout << endl;
    cout << "InOrder: ";
    b1.InOrder(root);
    cout << endl;
    cout << "PostOrder: ";
    b1.PostOrder(root);
    cout << endl;
    cout << b1.height(root) << endl;
    cout << "BST (Level-Order): ";
    b1.BFS(root);
    cout << endl;
    TreeNode *r2 = b1.DeleteNode(root, 6);
    cout << "BST (Level-Order) After deleting Node: ";
    b1.BFS(root);
    return 0;
}