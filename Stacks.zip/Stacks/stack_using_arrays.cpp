#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
/*
! The Stacks follow:
* First in Last out (FIlO) or Last in First out (LIFO) order.
? It means the value that was entered first, will remove at the last.
*/
class Stack
{
    int array[5];
    int pointer;
    const int null = 0;

public:
    Stack()
    {
        pointer = -1;
    }
    bool isEmpty()
    {
        if (pointer == -1)
            return true;
        else
            return false;
    }
    bool isFull()
    {
        if (pointer == 4)
            return true;
        else
            return false;
    }
    void push(int value)
    {
        if (isFull())
        {
            cout << "Stack is Full";
        }
        else
        {
            pointer++;
            array[pointer] = value;
        }
    }
    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack is Empty";
        }
        else
        {
            array[pointer] = null;
            pointer--;
        }
    }
    void change(int index, int value)
    {
        if (isEmpty())
        {
            cout << "Stack is Empty";
        }
        else if (index > pointer)
        {
            cout << "This index doesn't exists" << endl;
        }
        else
        {
            array[index] = value;
        }
    }
    void display()
    {
        if (pointer != -1)
        {
            for (int i = pointer; i >= 0; i--)
            {
                cout << array[i] << endl;
            }
        }
    }
    int count()
    {
        return (pointer + 1);
    }
};