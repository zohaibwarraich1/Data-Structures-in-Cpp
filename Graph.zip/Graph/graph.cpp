#include <iostream>
#include <map>
#include <vector>
#include <stack>
#include "vertex.cpp"
using namespace std;

//! Directed Graph
class Directed_Graph
{
    vector<Vertex> vertices;

public:
    void addEdge(int from, int to, int weight)
    {
        bool check1 = checkVertexExistence(from);
        bool check2 = checkVertexExistence(to);
        if (check1 == true && check2 == true)
        {
            bool check3 = checkEdgeExistence(from, to);
            if (check3 == true)
            {
                cout << "Edge already Exists!" << endl;
                return;
            }
            else
            {
                for (int i = 0; i < vertices.size(); i++)
                {
                    if (vertices[i].state_id == from)
                    {
                        Edge e = Edge(to, weight);
                        vertices[i].edgeList.push_back(e);
                    }
                }
            }
        }
        else
        {
            cout << "Vertices are not valid!" << endl;
        }
    }
    void deleteEdge(int from, int to)
    {
        bool check1 = checkVertexExistence(from);
        bool check2 = checkVertexExistence(to);
        if (check1 == true && check2 == true)
        {
            bool check3 = checkEdgeExistence(from, to);
            if (check3 == false)
            {
                cout << "Edge does not Exists!" << endl;
                return;
            }
            else
            {
                for (int i = 0; i < vertices.size(); i++)
                {
                    if (vertices[i].state_id == from)
                    {
                        for (int j = 0; j < vertices[i].edgeList.size(); j++)
                        {
                            if (vertices[i].edgeList[j].desitnationID == to)
                            {
                                vertices[i].edgeList.erase(vertices[i].edgeList.begin() + j);
                                break;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            cout << "Vertices are not valid!" << endl;
        }
    }
    void addVertex(Vertex new_vertex)
    {
        if (checkVertexExistence(new_vertex.state_id))
        {
            cout << "Vertex Already exists!" << endl;
        }
        else
        {
            vertices.push_back(new_vertex);
        }
    }
    void PrintGraph()
    {
        for (int i = 0; i < vertices.size(); i++)
        {
            cout << vertices[i].state_name << " (" << vertices[i].state_id << ") --> ";
            vertices[i].PrintVertex();
            cout << endl;
        }
    }
    void deleteVertex(int vid)
    {
        if (checkVertexExistence(vid))
        {
            int vindex = 0;
            for (int i = 0; i < vertices.size(); i++)
            {
                if (vertices[i].state_id == vid)
                {
                    vindex = i;
                    break;
                }
            }
            int size = vertices[vindex].edgeList.size(); //? Here we declared the size separately because while removing the edges, the size of edgeList changes which cause the iteration for other edges in edgeList (like skip some of the edges)
            for (int i = 0; i < size; i++)
            {
                cout << vertices[vindex].edgeList[i].desitnationID << endl;
                deleteEdge(vertices[vindex].edgeList[i].desitnationID, vid);
            }
            vertices.erase(vertices.begin() + vindex);
        }
        else
        {
            cout << "Vertex does not Exists!" << endl;
        }
    }
    void updateEdge(int from, int to, int new_weight)
    {
        bool check1 = checkVertexExistence(from);
        bool check2 = checkVertexExistence(to);
        if (check1 == true && check2 == true)
        {
            bool check3 = checkEdgeExistence(from, to);
            if (check3 == false)
            {
                cout << "Edge does not Exists!" << endl;
                return;
            }
            else
            {
                for (int i = 0; i < vertices.size(); i++)
                {
                    if (vertices[i].state_id == from)
                    {
                        for (int j = 0; j < vertices[i].edgeList.size(); j++)
                        {
                            if (vertices[i].edgeList[j].desitnationID == to)
                            {
                                vertices[i].edgeList[j].weight = new_weight;
                                break;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            cout << "Vertices are not valid!" << endl;
        }
    }
    void updateVertex(int vid, string name)
    {
        if (checkVertexExistence(vid))
        {
            for (int i = 0; i < vertices.size(); i++)
            {
                if (vertices[i].state_id == vid)
                {
                    vertices[i].state_name = name;
                    break;
                }
            }
        }
        else
        {
            cout << "Vertex does not Exists!";
        }
    }
    void TopologicalSort()
    {
        map<int, bool> vis;
        stack<int> st;
        for (int i = 0; i < vertices.size(); i++)
        {
            if (vis[vertices[i].state_id] == false)
            {
                TopologicalDFS(vis, vertices[i].state_id, i, st);
            }
        }
        while (!st.empty())
        {
            cout << st.top() << " ";
            st.pop();
        }
    }
    void TopologicalDFS(map<int, bool> &vis, int curr, int vindex, stack<int> &st)
    {
        vis[curr] = true;
        for (int i = 0; i < vertices[vindex].edgeList.size(); i++)
        {
            Edge e = vertices[vindex].edgeList[i];
            if (vis[e.desitnationID] == false)
            {
                TopologicalDFS(vis, e.desitnationID, vindex, st);
            }
        }
        st.push(curr);
    }
    void Dijkstra()
    {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        map<int, int> visited;
        pq.push({0, 0});
        vector<int> distances(vertices.size(), INT_MAX);
        distances[0] = 0;
        while (!pq.empty())
        {
            pair<int, int> p = pq.top();
            pq.pop();
            if (visited[p.second] == false)
            {
                visited[p.second] = true;
                for (int i = 0; i < vertices[p.second].edgeList.size(); i++)
                {
                    Edge e = vertices[p.second].edgeList[i];
                    if (distances[p.second] + e.weight < distances[e.desitnationID])
                    {
                        distances[e.desitnationID] = distances[p.second] + e.weight;
                        pq.push({distances[e.desitnationID], e.desitnationID});
                    }
                }
            }
        }
        for (int i = 0; i < distances.size(); i++)
        {
            cout << distances[i] << " ";
        }
        cout << endl;
    }
    void Bellman_Ford()
    {
        vector<int> distances(vertices.size(), INT_MAX);
        distances[0] = 0;
        for (int k = 0; k < vertices.size() - 1; k++)
        {
            for (int i = 0; i < vertices.size(); i++)
            {
                for (int j = 0; j < vertices[i].edgeList.size(); j++)
                {
                    Edge e = vertices[i].edgeList[j];
                    if (distances[i] + e.weight < distances[e.desitnationID])
                    {
                        distances[e.desitnationID] = distances[i] + e.weight;
                    }
                }
            }
        }
        for (int i = 0; i < distances.size(); i++)
        {
            cout << distances[i] << " ";
        }
        cout << endl;
    }

private:
    bool checkEdgeExistence(int from, int to)
    {
        vector<Edge> tempList = findvertexByID(from).edgeList;
        for (int i = 0; i < tempList.size(); i++)
        {
            if (tempList[i].desitnationID == to)
            {
                return true;
            }
        }
        return false;
    }
    Vertex findvertexByID(int vid)
    {
        Vertex temp;
        for (int i = 0; i < vertices.size(); i++)
        {
            if (vertices[i].state_id == vid)
            {
                return vertices[i];
            }
        }
        return temp;
    }
    bool checkVertexExistence(int vId)
    {
        for (int i = 0; i < vertices.size(); i++)
        {
            if (vertices[i].state_id == vId)
            {
                return true;
            }
        }
        return false;
    }
};

//! Undirected Graph
class Undirected_Graph
{
    vector<Vertex> vertices;

public:
    void addEdge(int from, int to, int weight)
    {
        bool check1 = checkVertexExistence(from);
        bool check2 = checkVertexExistence(to);
        if (check1 == true && check2 == true)
        {
            bool check3 = checkEdgeExistence(from, to);
            if (check3 == true)
            {
                cout << "Edge already Exists!" << endl;
                return;
            }
            else
            {
                for (int i = 0; i < vertices.size(); i++)
                {
                    if (vertices[i].state_id == from)
                    {
                        Edge e = Edge(to, weight);
                        vertices[i].edgeList.push_back(e);
                    }
                }
            }
        }
        else
        {
            cout << "Vertices are not valid!" << endl;
        }
    }
    void deleteEdge(int from, int to)
    {
        bool check1 = checkVertexExistence(from);
        bool check2 = checkVertexExistence(to);
        if (check1 == true && check2 == true)
        {
            bool check3 = checkEdgeExistence(from, to);
            if (check3 == false)
            {
                cout << "Edge does not Exists!" << endl;
                return;
            }
            else
            {
                for (int i = 0; i < vertices.size(); i++)
                {
                    if (vertices[i].state_id == from)
                    {
                        for (int j = 0; j < vertices[i].edgeList.size(); j++)
                        {
                            if (vertices[i].edgeList[j].desitnationID == to)
                            {
                                vertices[i].edgeList.erase(vertices[i].edgeList.begin() + j);
                                break;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            cout << "Vertices are not valid!" << endl;
        }
    }
    void addVertex(Vertex new_vertex)
    {
        if (checkVertexExistence(new_vertex.state_id))
        {
            cout << "Vertex Already exists!" << endl;
        }
        else
        {
            vertices.push_back(new_vertex);
        }
    }
    void PrintGraph()
    {
        for (int i = 0; i < vertices.size(); i++)
        {
            cout << vertices[i].state_name << " (" << vertices[i].state_id << ") --> ";
            vertices[i].PrintVertex();
            cout << endl;
        }
    }
    void deleteVertex(int vid)
    {
        if (checkVertexExistence(vid))
        {
            int vindex = 0;
            for (int i = 0; i < vertices.size(); i++)
            {
                if (vertices[i].state_id == vid)
                {
                    vindex = i;
                    break;
                }
            }
            int size = vertices[vindex].edgeList.size(); //? Here we declared the size separately because while removing the edges, the size of edgeList changes which cause the iteration for other edges in edgeList (like skip some of the edges)
            for (int i = 0; i < size; i++)
            {
                cout << vertices[vindex].edgeList[i].desitnationID << endl;
                deleteEdge(vertices[vindex].edgeList[i].desitnationID, vid);
            }
            vertices.erase(vertices.begin() + vindex);
        }
        else
        {
            cout << "Vertex does not Exists!" << endl;
        }
    }
    void updateEdge(int from, int to, int new_weight)
    {
        bool check1 = checkVertexExistence(from);
        bool check2 = checkVertexExistence(to);
        if (check1 == true && check2 == true)
        {
            bool check3 = checkEdgeExistence(from, to);
            if (check3 == false)
            {
                cout << "Edge does not Exists!" << endl;
                return;
            }
            else
            {
                for (int i = 0; i < vertices.size(); i++)
                {
                    if (vertices[i].state_id == from)
                    {
                        for (int j = 0; j < vertices[i].edgeList.size(); j++)
                        {
                            if (vertices[i].edgeList[j].desitnationID == to)
                            {
                                vertices[i].edgeList[j].weight = new_weight;
                                break;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            cout << "Vertices are not valid!" << endl;
        }
    }
    void updateVertex(int vid, string name)
    {
        if (checkVertexExistence(vid))
        {
            for (int i = 0; i < vertices.size(); i++)
            {
                if (vertices[i].state_id == vid)
                {
                    vertices[i].state_name = name;
                    break;
                }
            }
        }
        else
        {
            cout << "Vertex does not Exists!";
        }
    }
    void TopologicalSort()
    {
        map<int, bool> vis;
        stack<int> st;
        for (int i = 0; i < vertices.size(); i++)
        {
            if (vis[vertices[i].state_id] == false)
            {
                TopologicalDFS(vis, vertices[i].state_id, i, st);
            }
        }
        while (!st.empty())
        {
            cout << st.top() << " ";
            st.pop();
        }
    }
    void TopologicalDFS(map<int, bool> &vis, int curr, int vindex, stack<int> &st)
    {
        vis[curr] = true;
        for (int i = 0; i < vertices[vindex].edgeList.size(); i++)
        {
            Edge e = vertices[vindex].edgeList[i];
            if (vis[e.desitnationID] == false)
            {
                TopologicalDFS(vis, e.desitnationID, vindex, st);
            }
        }
        st.push(curr);
    }
    void Dijkstra()
    {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        map<int, int> visited;
        pq.push({0, 0});
        vector<int> distances(vertices.size(), INT_MAX);
        distances[0] = 0;
        while (!pq.empty())
        {
            pair<int, int> p = pq.top();
            pq.pop();
            if (visited[p.second] == false)
            {
                visited[p.second] = true;
                for (int i = 0; i < vertices[p.second].edgeList.size(); i++)
                {
                    Edge e = vertices[p.second].edgeList[i];
                    if (distances[p.second] + e.weight < distances[e.desitnationID])
                    {
                        distances[e.desitnationID] = distances[p.second] + e.weight;
                        pq.push({distances[e.desitnationID], e.desitnationID});
                    }
                }
            }
        }
        for (int i = 0; i < distances.size(); i++)
        {
            cout << distances[i] << " ";
        }
        cout << endl;
    }
    void Bellman_Ford()
    {
        vector<int> distances(vertices.size(), INT_MAX);
        distances[0] = 0;
        for (int k = 0; k < vertices.size() - 1; k++)
        {
            for (int i = 0; i < vertices.size(); i++)
            {
                for (int j = 0; j < vertices[i].edgeList.size(); j++)
                {
                    Edge e = vertices[i].edgeList[j];
                    if (distances[i] != INT_MAX && distances[i] + e.weight < distances[e.desitnationID])
                    {
                        distances[e.desitnationID] = distances[i] + e.weight;
                    }
                }
            }
        }
        for (int i = 0; i < distances.size(); i++)
        {
            cout << distances[i] << " ";
        }
        cout << endl;
    }

private:
    bool checkEdgeExistence(int from, int to)
    {
        vector<Edge> tempList = findvertexByID(from).edgeList;
        for (int i = 0; i < tempList.size(); i++)
        {
            if (tempList[i].desitnationID == to)
            {
                return true;
            }
        }
        return false;
    }
    Vertex findvertexByID(int vid)
    {
        Vertex temp;
        for (int i = 0; i < vertices.size(); i++)
        {
            if (vertices[i].state_id == vid)
            {
                return vertices[i];
            }
        }
        return temp;
    }
    bool checkVertexExistence(int vId)
    {
        for (int i = 0; i < vertices.size(); i++)
        {
            if (vertices[i].state_id == vId)
            {
                return true;
            }
        }
        return false;
    }
};