#include <iostream>
using namespace std;
class Edge
{
public:
    int desitnationID;
    int weight;
    Edge()
    {
    }
    Edge(int id, int weight)
    {
        this->desitnationID = id;
        this->weight = weight;
    }
};