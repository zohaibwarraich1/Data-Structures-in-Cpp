#include <iostream>
#include "graph.cpp"
using namespace std;
int main()
{
    Undirected_Graph g;
    Vertex isb = Vertex(0, "isb");
    Vertex fsd = Vertex(1, "fsd");
    Vertex lhr = Vertex(2, "lhr");
    Vertex multan = Vertex(3, "multan");
    Vertex psh = Vertex(4, "peshawar");
    Vertex karachi = Vertex(5, "karachi");
    g.addVertex(isb);
    g.addVertex(fsd);
    g.addVertex(lhr);
    g.addVertex(multan);
    g.addVertex(psh);
    // g.addVertex(karachi);
    g.addEdge(0, 1, 2);
    g.addEdge(0, 2, 4);
    g.addEdge(1, 2, -4);
    g.addEdge(2, 3, 2);
    g.addEdge(3, 4, 4);
    g.addEdge(4, 1, -1);
    g.Dijkstra();
    g.Bellman_Ford();
    // g.PrintGraph();
    // g.TopologicalSort();
    // cout << endl;
    // g.addEdge(1, 2, 4);
    // g.PrintGraph();
    // cout << endl;
    // g.deleteEdge(1, 3);
    // g.PrintGraph();
    // cout << endl;
    // g.deleteVertex(4);
    // g.PrintGraph();
    // cout << endl;
    // g.updateEdge(1, 2, 2);
    // g.PrintGraph();
    // cout << endl;
    // g.updateVertex(1, "multan");
    // g.PrintGraph();
    // cout << endl;
    return 0;
}