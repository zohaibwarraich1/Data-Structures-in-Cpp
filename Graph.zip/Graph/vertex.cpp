#include <iostream>
#include <vector>
#include "edge.cpp"
using namespace std;
class Vertex
{
public:
    int state_id;
    string state_name;
    vector<Edge> edgeList;
    Vertex()
    {
    }
    Vertex(int sID, string sName)
    {
        state_id = sID;
        state_name = sName;
    }
    void PrintVertex()
    {
        cout << "[";
        for (int i = 0; i < edgeList.size(); i++)
        {
            cout << edgeList[i].desitnationID << "(" << edgeList[i].weight << ")";
            if (i < edgeList.size() - 1)
                cout << " --> ";
        }
        cout << "]";
    }
};