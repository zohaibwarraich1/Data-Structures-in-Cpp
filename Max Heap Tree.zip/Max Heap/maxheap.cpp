#include <iostream>
using namespace std;
class MaxHeap
{
public:
    int *parr;     //? pointer to array of elements in heap
    int capacity;  //? maximum possible size of min heap
    int heap_size; //? Current number of elements in min heap
    ~MaxHeap()
    {
        delete[] parr;
    }
    MaxHeap(int cap)
    {
        heap_size = 0;
        capacity = cap;
        parr = new int[cap];
    }

private:
    int parent(int i)
    {
        return (i - 1) / 2;
    }
    int left(int i)
    {
        return (2 * i + 1);
    }
    int right(int i)
    {
        return (2 * i + 2);
    }

public:
    int getMax()
    {
        return parr[0];
    }
    void insertKey(int k)
    {
        if (heap_size == capacity)
        {
            cout << "\nOverflow: Could not insert Key\n";
            return;
        }
        //? First insert the new key at the end
        heap_size++;
        int i = heap_size - 1;
        parr[i] = k;
        //? Fix the max heap property if it is violated
        while (i != 0 && parr[parent(i)] < parr[i])
        {
            swap(parr[i], parr[parent(i)]);
            i = parent(i);
        }
    }
    void linearSearch(int val)
    {
        for (int i = 0; i < heap_size; i++)
        {
            if (parr[i] == val)
            {
                cout << "Value Found!";
                return;
            }
        }
        cout << "Value NOT Found!";
    }
    void printArray()
    {
        for (int i = 0; i < heap_size; i++)
            cout << parr[i] << " ";
        cout << endl;
    }
    int extractMax()
    {
        if (heap_size <= 0)
        {
            cout << "There is no element in heap";
            return 0;
        }
        if (heap_size == 1)
        {
            heap_size--;
            return parr[heap_size];
        }
        int root = parr[0];
        parr[0] = parr[heap_size - 1];
        heap_size--;
        MaxHeapify(0);
        return root;
    }
    void MaxHeapify(int i)
    {
        int l = left(i);
        int r = right(i);
        int largest = i;
        if (l < heap_size && parr[l] > parr[largest])
        {
            largest = l;
        }
        if (r < heap_size && parr[r] > parr[largest])
        {
            largest = r;
        }
        if (largest != i)
        {
            swap(parr[largest], parr[i]);
            MaxHeapify(largest);
        }
    }
    void Delete(int i)
    {
        parr[i] = INT_MAX;
        while (i != 0 && parr[parent(i)] < parr[i])
        {
            swap(parr[i], parr[parent(i)]);
            i = parent(i);
        }
        int temp = extractMax();
    }
};