#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
string PostToInfix(string prefix)
{
    stack<string> st;
    for (int i = prefix.length() - 1; i >= 0; i--)
    {
        if ((prefix[i] >= 'A' && prefix[i] <= 'Z') || (prefix[i] >= 'a' && prefix[i] <= 'z'))
        {
            string op;
            op.push_back(prefix[i]);
            st.push(op);
        }
        else
        {
            string op1 = st.top();
            st.pop();
            string op2 = st.top();
            st.pop();
            st.push(op1 + op2 + prefix[i]);
        }
    }
    return st.top();
}
int main()
{
    string prefix = "/*-+abc^d^efg";
    cout << PostToInfix(prefix);
    return 0;
}