#include <iostream>
#include "DoublyLinkedList.cpp"
using namespace std;
class CircularLinkedList
{
    Node *head = nullptr;
    bool NodeExists(int key)
    {
        if (head == nullptr)
            return false;
        else
        {
            Node *tempHead = head;
            do
            {
                if (tempHead->GetKey() == key)
                {
                    return true;
                }
                tempHead = tempHead->next;
            } while (tempHead != head);
        }
        return false;
    }

public:
    CircularLinkedList(Node *head_node)
    {
        head = head_node;
    }
    void InsertAtLast(Node *n)
    {
        if (NodeExists(n->GetKey()) == true)
        {
            cout << "Node already Exists!" << endl;
            cout << "Append another Node." << endl;
        }
        else
        {
            if (head == nullptr)
            {
                head = n;
                n->next = head;
            }
            else
            {
                Node *tempHead = head;
                while (tempHead->next != head)
                {
                    tempHead = tempHead->next;
                }
                tempHead->next = n;
                n->next = head;
            }
        }
    }
    void InsertAtFirst(Node *n)
    {
        if (NodeExists(n->GetKey()) == true)
        {
            cout << "Node already Exists!" << endl;
            cout << "Prepend another Node." << endl;
        }
        else
        {
            Node *tempHead = head;
            while (tempHead->next != head)
            {
                tempHead = tempHead->next;
            }
            tempHead->next = n;
            n->next = head;
            head = n;
        }
    }
    void InsertNode(int key, Node *n)
    {
        if (NodeExists(key) == false)
        {
            cout << "No Node exists with key: " << key << endl;
            cout << "Please try another key to insert Node." << endl;
        }
        else
        {
            if (NodeExists(n->GetKey()) == true)
            {
                cout << "Node already Exists with key: " << n->GetKey() << endl;
                cout << "Choose another key to insert Node" << endl;
            }
            else
            {
                Node *temp = head;
                while (temp->GetKey() != key)
                {
                    temp = temp->next;
                }
                n->next = temp->next;
                temp->next = n;
            }
        }
    }
    void deleteNode(int key)
    {
        if (NodeExists(key) == false)
        {
            cout << "No Node exists with key: " << key << endl;
            cout << "Please try another key to insert Node." << endl;
        }
        else
        {
            if (head->GetKey() == key)
            {
                if (head->next == head)
                {
                    head = nullptr;
                }
                else
                {
                    Node *temp = head;
                    while (temp->next != head)
                    {
                        temp = temp->next;
                    }
                    temp->next = head->next;
                    head = head->next;
                }
            }
            else
            {
                bool nodeFound = true;
                Node *preNode = head;
                Node *afterPreNode = head->next;
                while (afterPreNode->GetKey() != key)
                {
                    if (afterPreNode->next == head)
                    {
                        nodeFound = false;
                        break;
                    }
                    else
                    {
                        afterPreNode = afterPreNode->next;
                        preNode = preNode->next;
                    }
                }
                if (nodeFound)
                {
                    preNode->next = afterPreNode->next;
                }
                else
                {
                    cout << "Node with key " << key << " doesn't exist!!" << endl;
                }
            }
        }
    }
    void updateNode(int key, int value)
    {
        if (NodeExists(key) == true)
        {
            Node *temp = head;
            do
            {
                if (temp->GetKey() == key)
                {
                    temp->data = value;
                    break;
                }
                temp = temp->next;
            } while (temp != head);
            // while (temp->GetKey() != key)
            // {
            //     temp = temp->next;
            // }
            // temp->data = value;
        }
        else
        {
            cout << "Node with key " << key << " doesn't exist!!" << endl;
        }
    }
    void display()
    {
        if (head != NULL)
        {
            Node *temp = head;
            do
            {
                cout << temp->data;
                if (temp->next != head)
                {
                    cout << " -> ";
                }
                temp = temp->next;
            } while (temp != head);
            cout << endl;
        }
        else
            cout << "No Node exists in the list !!" << endl;
    }
};