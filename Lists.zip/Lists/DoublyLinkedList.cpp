#include <iostream>
#include "SinglyLinkedList.cpp"
using namespace std;
class DoublyLinkedList
{
    Node *head = nullptr;
    bool NodeExists(int key)
    {
        Node *tempHead = head;
        while (tempHead != NULL)
        {
            if (tempHead->GetKey() == key)
            {
                return true;
            }
            tempHead = tempHead->next;
        }
        return false;
    }
public:
    DoublyLinkedList(Node *head_node)
    {
        head = head_node;
    }
    void InsertAtLast(Node *n)
    {
        if (NodeExists(n->GetKey()) == true)
        {
            cout << "Node already Exists!" << endl;
            cout << "Append another Node." << endl;
        }
        else
        {
            if (head == nullptr)
            {
                head = n;
            }
            else
            {
                Node *tempHead = head;
                while (tempHead->next != NULL)
                {
                    tempHead = tempHead->next;
                }
                tempHead->next = n;
                n->previous = tempHead;
            }
        }
    }
    void InsertAtFirst(Node *n)
    {
        if (NodeExists(n->GetKey()) == true)
        {
            cout << "Node already Exists!" << endl;
            cout << "Prepend another Node." << endl;
        }
        else
        {
            if (head == NULL)
            {
                head = n;
            }
            else
            {
                n->next = head;
                head->previous = n;
                head = n;
            }
        }
    }
    void InsertNode(int key, Node *n)
    {
        if (NodeExists(key) == false)
        {
            cout << "No Node exists with key: " << key << endl;
            cout << "Please try another key to insert Node." << endl;
        }
        else
        {
            if (NodeExists(n->GetKey()) == true)
            {
                cout << "Node already Exists with key: " << n->GetKey() << endl;
                cout << "Choose another key to insert Node" << endl;
            }
            else
            {
                Node *node_till_key = head;
                while (node_till_key->GetKey() != key)
                {
                    node_till_key = node_till_key->next;
                }
                if (node_till_key->next == nullptr)
                {
                    n->next = node_till_key->next;
                    n->previous = node_till_key;
                    node_till_key->next = n;
                }
                else
                {
                    n->next = node_till_key->next;
                    n->previous = node_till_key;
                    node_till_key->next = n;
                    n->next->previous = n;
                }
            }
        }
    }
    void deleteNode(int key)
    {
        if (head == NULL)
        {
            cout << "No Node exists in the list. Can't Delete!!" << endl;
        }
        else
        {
            if (head->GetKey() == key)
            {
                if (head->next != NULL)
                {
                    head = head->next;
                    head->previous = nullptr;
                }
                else
                {
                    head = NULL;
                }
            }
            else
            {
                bool nodeFound = true;
                Node *preNode = head;
                Node *afterPreNode = head->next;
                while (afterPreNode->GetKey() != key)
                {
                    if (afterPreNode->next == NULL)
                    {
                        nodeFound = false;
                        break;
                    }
                    else
                    {
                        afterPreNode = afterPreNode->next;
                        preNode = preNode->next;
                    }
                }
                if (nodeFound)
                {
                    preNode->next = afterPreNode->next;
                    afterPreNode->next->previous = preNode;
                }
                else
                {
                    cout << "Node with key " << key << " doesn't exist!!" << endl;
                }
            }
        }
    }
    void updateNode(int key, int value)
    {
        if (NodeExists(key) == true)
        {
            Node *temp = head;
            while (temp->GetKey() != key)
            {
                temp = temp->next;
            }
            temp->data = value;
        }
        else
        {
            cout << "Node with key " << key << " doesn't exist!!" << endl;
        }
    }
    void display()
    {
        if (head != NULL)
        {
            Node *temp = head;
            while (temp != NULL)
            {
                cout << temp->data;
                if (temp->next != nullptr)
                {
                    cout << " -> ";
                }
                temp = temp->next;
            }
            cout << endl;
        }
        else
            cout << "No Node exists in the list !!" << endl;
    }
};