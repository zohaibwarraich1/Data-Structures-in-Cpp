#include <iostream>
#include "Node.cpp"
using namespace std;
class SinglyLinkedList
{
    Node *head = NULL;
    bool NodeExists(int key)
    {
        Node *tempHead = head;
        while (tempHead != NULL)
        {
            if (tempHead->GetKey() == key)
            {
                return true;
            }
            tempHead = tempHead->next;
        }
        return false;
    }

public:
    SinglyLinkedList(Node *head_node)
    {
        head = head_node;
    }
    void InsertAtLast(Node *n)
    {
        if (NodeExists(n->GetKey()) == true)
        {
            cout << "Node already Exists!" << endl;
            cout << "Append another Node." << endl;
        }
        else
        {
            if (head == NULL)
            {
                head = n;
            }
            else
            {
                Node *tempHead = head;
                while (tempHead->next != NULL)
                {
                    tempHead = tempHead->next;
                }
                tempHead->next = n;
            }
        }
    }
    void InsertAtFirst(Node *n)
    {
        if (NodeExists(n->GetKey()) == true)
        {
            cout << "Node already Exists!" << endl;
            cout << "Prepend another Node." << endl;
        }
        else
        {
            if (head == NULL)
            {
                head = n;
            }
            else
            {
                n->next = head;
                head = n;
            }
        }
    }
    void InsertNode(int key, Node *n)
    {
        if (NodeExists(key) == false)
        {
            cout << "No Node exists with key: " << key << endl;
            cout << "Please try another key to insert Node." << endl;
        }
        else
        {
            if (NodeExists(n->GetKey()) == true)
            {
                cout << "Node already Exists with key: " << n->GetKey() << endl;
                cout << "Choose another key to insert Node" << endl;
            }
            else
            {
                Node *node_till_key = head;
                while (node_till_key->GetKey() != key)
                {
                    node_till_key = node_till_key->next;
                }
                n->next = node_till_key->next;
                node_till_key->next = n;
            }
        }
    }
    void deleteNode(int key)
    {
        if (head == NULL)
        {
            cout << "No Node exists in the list. Can't Delete!!" << endl;
        }
        else
        {
            if (head->GetKey() == key)
            {
                if (head->next != NULL)
                {
                    head = head->next;
                }
                else
                {
                    head = NULL;
                }
            }
            else
            {
                bool nodeFound = true;
                Node *afterPreNode = head->next;
                Node *preNode = head;

                //! Method 1
                while (afterPreNode->GetKey() != key)
                {
                    if (afterPreNode->next == NULL)
                    {
                        nodeFound = false;
                        break;
                    }
                    else
                    {
                        afterPreNode = afterPreNode->next;
                        preNode = preNode->next;
                    }
                }
                //! Method 2
                // while (nodeFound == true)
                // {
                //     if (tempHead->GetKey() == key)
                //     {
                //         nodeFound = false;
                //     }
                //     else
                //     {
                //         tempHead = tempHead->next;
                //         preNode = preNode->next;
                //     }
                // }
                if (nodeFound)
                {
                    preNode->next = afterPreNode->next;
                }
                else
                {
                    cout << "Node with key " << key << " doesn't exist!!" << endl;
                }
            }
        }
    }
    void updateNode(int key, int value)
    {
        if (NodeExists(key) == true)
        {
            Node *temp = head;
            while (temp->GetKey() != key)
            {
                temp = temp->next;
            }
            temp->data = value;
        }
        else
        {
            cout << "Node with key " << key << " doesn't exist!!" << endl;
        }
    }
    void display()
    {
        if (head != NULL)
        {
            Node *temp = head;
            while (temp != NULL)
            {
                cout << temp->data;
                if (temp->next != nullptr)
                {
                    cout << " -> ";
                }
                temp = temp->next;
            }
            cout << endl;
        }
        else
            cout << "No Node exists in the list !!" << endl;
    }
    void InsertHeadNode(Node *n)
    {
        if (head == NULL)
        {
            head = n;
        }
        else
        {
            cout << "Head Node already exists !!" << endl;
        }
    }
};