#include <iostream>
using namespace std;
class Node
{
private:
    static int key_iterator;
    int key;
    void KeyIterator()
    {
        key_iterator++;
        key = key_iterator;
    }

public:
    int data;
    Node *next = NULL;
    Node *previous = NULL;
    Node()
    {
        KeyIterator();
    }
    Node(int value)
    {
        this->data = value;
        KeyIterator();
    }
    int GetKey()
    {
        return key;
    }
};
int Node::key_iterator = 0;