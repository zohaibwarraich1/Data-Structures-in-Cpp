#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int BinarySearch(int array[], int search, int right)
{
    int left = 0;
    while (left <= right)
    {
        int mid = (left + right) / 2; //* or we can use this formula -> left+(right-left)/2
        if (array[mid] == search)
        {
            return mid;
        }
        else if (array[mid] < search)
        {
            left = mid + 1;
        }
        else
        {
            right = mid - 1;
        }
    }
    return -1;
}
int main()
{
    int array[10] = {2, 5, 8, 19, 28, 43, 52, 61, 74, 89};
    int search = 28;
    int right = (sizeof(array) / 4) - 1;
    int result = BinarySearch(array, search, right);
    if (result == -1)
        cout << "Element not found" << endl;
    else
        cout << "Element found" << endl;
    return 0;
}