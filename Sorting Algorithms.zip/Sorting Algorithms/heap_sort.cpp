#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;

//! This is MinHeap (sorting in ascending order)

int parent(int i)
{
    return (i - 1) / 2;
}
int left(int i)
{
    return (2 * i + 1);
}
int right(int i)
{
    return (2 * i + 2);
}
void MinHeapify(vector<int> &parr, int heap_size, int i)
{
    int l = left(i);
    int r = right(i);
    int smallest = i;
    if (l < heap_size && parr[l] < parr[i])
    {
        smallest = l;
    }
    if (r < heap_size && parr[r] < parr[smallest]) //? we should compare r with smallest index because if smallest index doesnt change in upper if condition then we will again check the index i (smallest) with its right child not with the left child.
    {
        smallest = r;
    }
    if (smallest != i)
    {
        swap(parr[smallest], parr[i]);
        MinHeapify(parr, heap_size, smallest);
    }
}
int extractMin(vector<int> &parr, int heap_size)
{
    if (heap_size <= 0)
    {
        cout << "There is no element in heap";
        return 0;
    }
    if (heap_size == 1)
    {
        heap_size--;
        return parr[heap_size];
    }
    int root = parr[0];
    parr[0] = parr[heap_size - 1];
    heap_size--;
    MinHeapify(parr, heap_size, 0);
    return root;
}
vector<int> HeapSort(vector<int> &arr)
{
    int size = arr.size();
    for (int i = 0; i < size / 2; i++)
    {
        MinHeapify(arr, size, i);
    }
    vector<int> sorted;
    for (int i = 0; i < size; i++)
    {
        sorted.push_back(extractMin(arr, (size - i)));
    }
    return sorted;
}
int main()
{
    vector<int> arr = {8, 9, 0, 9, 2, 7, 1, 8, 2, 5, 6, 1, 8, 4, 9, 123, 78, 289, 44, 97};
    vector<int> result = HeapSort(arr);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}