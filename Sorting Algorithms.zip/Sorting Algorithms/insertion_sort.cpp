#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
void InsertionSort(vector<int> &arr)
{
    for (int i = 1; i < arr.size(); i++)
    {
        int storeIndexVal = arr[i];
        int j = i - 1;
        for (; j >= 0 && arr[j] > storeIndexVal; j--)
        {
            arr[j + 1] = arr[j];
        }
        arr[j + 1] = storeIndexVal;
    }
}
int main()
{
    vector<int> arr = {28, 64, 27, 12, 11, 80};
    InsertionSort(arr);
    for (int i = 0; i < arr.size(); i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
    return 0;
}