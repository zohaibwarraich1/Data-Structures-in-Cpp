#include <iostream>
using namespace std;
/*
! In this Circular queue, the enqueue and dequeue is in the circular way.
! ! Example: If we enqueue 5 numbers.
? The order will be: 2->3->6->8->5
! After that if dequeue one value i.e(2)
? The order will be: 0->3->6->8->5
! Now if we try to again enter the value, it will add in the first index where the recent value was dequeued.
? Now the order will be if we enter -> 11 : 11->3->6->8->5
* But the next dequeue value will be the next index i.e (value: 3, index: 1) not the first index.
! Similary, if we dequeue after the last 5th value the next dequeue will start from first index again.
* """This is the circular movement of enqueue and dequeue""".
*/
class CircularQueue
{
    int n = 5;
    int array[5];
    int rear;
    int front;
    int valueCount;

public:
    CircularQueue()
    {
        for (int i = 0; i < 5; i++)
        {
            array[i] = 0;
        }
        valueCount = 0;
        rear = -1;
        front = -1;
    }
    bool isEmpty()
    {
        if (rear == -1 && front == -1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isFull()
    {
        if ((rear + 1) % n == front)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    void enqueue(int value)
    {
        if (isFull())
        {
            cout << "Queue is Full" << endl;
        }
        else
        {
            if (isEmpty())
            {
                rear = 0;
                front = 0;
            }
            else
            {
                rear = (rear + 1) % n;
            }
            array[rear] = value;
            valueCount++;
        }
    }
    void dequeue()
    {
        if (isEmpty())
        {
            cout << "Queue is Empty";
        }
        else
        {
            if (front == 0 && rear == 0)
            {
                array[front] = 0;
                front = -1;
                rear = -1;
            }
            else
            {
                array[front] = 0;
                front = (front + 1) % n;
            }
            valueCount--;
        }
    }
    int count()
    {

        return valueCount;
    }
    void display()
    {
        int temp = front;
        for (int i = front;; i++)
        {
            if (i == 5)
            {
                i = 0;
                temp = -2;
            }
            temp++;
            if (array[i] == 0 || temp == front - 1)
            {
                break;
            }
            cout << array[i] << " ";
        }
    }
};