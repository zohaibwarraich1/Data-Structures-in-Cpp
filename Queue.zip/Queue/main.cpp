#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include "Circular_Queue.cpp"
#include "Single_Queue.cpp"
#include "Single_Queue_using_linked_list.cpp"
using namespace std;
/*
! Both single and circular queue follow:
* First in First out (FIFO) or Last in Last out (LILO) order.
? It means the value that was enqueued(entered) first, will dequeue(remove) first.
*/
int main()
{
    cout << "---------- Circular Queue ----------\n";
    CircularQueue q1 = CircularQueue();
    q1.enqueue(2);
    q1.enqueue(5);
    q1.enqueue(6);
    q1.enqueue(4);
    q1.enqueue(7);
    cout << "Count: " << q1.count() << endl;
    q1.display();
    cout << endl;
    q1.dequeue();
    q1.dequeue();
    cout << "Count: " << q1.count() << endl;
    q1.display();
    cout << endl;
    q1.enqueue(9);
    q1.display();
    cout << endl;
    cout << q1.isFull() << " " << q1.isEmpty();
    cout << "\n---------- Single Queue ----------\n";
    SingleQueue sq = SingleQueue();
    sq.enqueue(2);
    sq.enqueue(5);
    sq.enqueue(6);
    sq.enqueue(4);
    cout << "Count: " << sq.count() << endl;
    sq.display();
    cout << endl;
    sq.dequeue();
    cout << "Count: " << sq.count() << endl;
    sq.display();
    cout << endl;
    cout << sq.isFull() << " " << sq.isEmpty();
    cout << "\n---------- Single Queue using Linked List ----------\n";
    Queue_Linked_List ql = Queue_Linked_List();
    cout << "Count: " << ql.count() << endl;
    ListNode *n1 = new ListNode(1);
    ListNode *n2 = new ListNode(2);
    ListNode *n3 = new ListNode(3);
    ListNode *n4 = new ListNode(4);
    ql.push_back(n1);
    ql.push_back(n2);
    ql.push_back(n3);
    ql.push_back(n4);
    cout << "Count: " << ql.count() << endl;
    cout << "Front: " << ql.front_value() << endl;
    ql.pop_front();
    cout << "Front: " << ql.front_value() << endl;
    ql.pop_front();
    cout << "Front: " << ql.front_value() << endl;
    ql.pop_front();
    cout << "Front: " << ql.front_value() << endl;
    return 0;
}